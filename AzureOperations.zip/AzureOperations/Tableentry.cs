﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
namespace AzureOperations
{
    public class Tableentry
    {
         string connstring;
         string rowKey;
         string partitionKey;
        public Tableentry(string StorageConnectionString, string rowkey, string partitionkey)
        {
            connstring = StorageConnectionString;
            rowKey = rowkey;
            partitionKey = partitionkey;
        }
        public string GetCurrentHourPartition(string tableName)
        {
            CloudStorageAccount cloudStorageAccount = CloudStorageAccount.Parse(connstring);
            CloudTableClient tableClient = cloudStorageAccount.CreateCloudTableClient();
            CloudTable cloudTable = tableClient.GetTableReference(tableName);
            cloudTable.CreateIfNotExists();
            TableOperation tableOperation = TableOperation.Retrieve<EventEntry>(partitionKey, rowKey);
            TableResult tableResult = cloudTable.Execute(tableOperation);
            EventEntry entry = tableResult.Result as EventEntry;
            if (entry == null)
            { return null; }
            else
            {
                return entry.CurrentHourPartition.ToString();
            }
        }
        public void UpdateorInsertHP(string tableName, string hourpartition)
        {
            CloudStorageAccount cloudStorageAccount = CloudStorageAccount.Parse(connstring);
            CloudTableClient tableClient = cloudStorageAccount.CreateCloudTableClient();
            CloudTable cloudTable = tableClient.GetTableReference(tableName);
            cloudTable.CreateIfNotExists();
            TableOperation tableOperation = TableOperation.Retrieve<EventEntry>(partitionKey, rowKey);
            TableResult tableResult = cloudTable.Execute(tableOperation);
            EventEntry entry = tableResult.Result as EventEntry;
            if (entry == null)
            {
                EventEntry entry1 = new EventEntry();
                entry1.AssignPartitionKey();
                entry1.AssignRowKey();
                entry1.CurrentHourPartition = hourpartition;
                TableOperation insertOperation = TableOperation.Insert(entry1);
                cloudTable.Execute(insertOperation);
                
            }
            else
            {
                entry.AssignPartitionKey();
                entry.AssignRowKey();
                entry.CurrentHourPartition = hourpartition;
                TableOperation updateOperation = TableOperation.Replace(entry);
                cloudTable.Execute(updateOperation);
            }
            
        }
    

    }
}
