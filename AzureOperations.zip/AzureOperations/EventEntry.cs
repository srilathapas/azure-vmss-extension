﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;

namespace AzureOperations
{
    class EventEntry : TableEntity
    {
       
        private string HourPartition;
        public void AssignRowKey()
        {
            this.RowKey = "currenthp";
        }
        public void AssignPartitionKey()
        {
            this.PartitionKey = "currenthp";
        }
        public string CurrentHourPartition
        {
            get
            {
                return HourPartition;
            }

            set
            {
                HourPartition = value;
            }
        }
       
    }
}
