﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.IO;
using System.Threading;
using System.Xml;
using Microsoft.Rest.Azure.Authentication;
using Microsoft.Azure.Management.DataLake.Store;
using Microsoft.Azure.Management.DataLake.Store.Models;
using Microsoft.Azure.Management.DataLake.StoreUploader;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System.Configuration;

namespace ADLSEvents
{
   public class ADLProcessor
    {
        private static DataLakeStoreAccountManagementClient _adlsClient;
        private static DataLakeStoreFileSystemManagementClient _adlsFileSystemClient;

        private static string _adlsAccountName;

        private static string _subId;
        private static string _aconnString;
        private static string _atableName;
        static string _hourlypartition;
        static string _eventMsgFile;
        static string _hourpartitionpath;
        static string _tenantId;
        private static readonly object _syncRoot = new object();

       /// <summary>
       /// ADL processor : functionality of merging files in to one.
       /// Current Hour partition is updated in azure table storage.
       /// </summary>
       /// <param name="configString">azure storage connection string</param>
       /// <param name="tablename">azure table name</param>
       /// <param name="eventMessage">event from event hub. only file path in adl should be passed here. ex:/data/2017031211.xml</param>
       /// <param name="hpartition">hour partition value ex: 2017031404 ; 14th Mar 4th hour </param>
       /// <param name="adlAccount">ADLS account name</param>
       /// <param name="subscription">Subscription ID</param>
       /// <param name="destFolderPath">destination folder path in ADLS. ex: /data/hourpartition</param>
         public static void Initialize(string configString,string tablename,string eventMessage,string hpartition,string adlAccount,string subscription,string destFolderPath,string tenantID)
         {
             _aconnString = configString;
             _atableName = tablename;
              _hourlypartition = hpartition;
               _eventMsgFile = eventMessage;
               _adlsAccountName = adlAccount;
               _subId = subscription;
               _hourpartitionpath = destFolderPath;
               _tenantId = tenantID;
         }
        public static void MergeFiles()
        {
            lock (_syncRoot)
            {
                //  = "sbadl"; // TODO: Replace this value with the name of your existing Data Lake Store account.           
                //  _subId = "44260363-bfba-4172-8de1-5dea00924217";
                //   _eventMsgFile = "/data/2017-03-13-13-04.xml";            




                /*
                 * Below code need to be replaced with authentication code currently used in System
                 * Starts here
                 * */

                SynchronizationContext.SetSynchronizationContext(new SynchronizationContext());
                var tenant_id = _tenantId;
                //  var tenant_id = "63ce7d59-2f3e-42cd-a8cc-be764cff5eb6"; // Replace this string with the user's Azure Active Directory tenant ID
                var nativeClientApp_clientId = "1950a258-227b-4e31-a9cf-717495945fc2";
                var activeDirectoryClientSettings = ActiveDirectoryClientSettings.UsePromptOnly(nativeClientApp_clientId, new Uri("urn:ietf:wg:oauth:2.0:oob"));
                var creds = UserTokenProvider.LoginWithPromptAsync(tenant_id, activeDirectoryClientSettings).Result;

                /*ends here*/
                // need to get the credentials in to creds variable

                // Create client objects and set the subscription ID
                _adlsClient = new DataLakeStoreAccountManagementClient(creds);
                _adlsFileSystemClient = new DataLakeStoreFileSystemManagementClient(creds);

                _adlsClient.SubscriptionId = _subId;
                AzureOperations.Tableentry _tableentry = new AzureOperations.Tableentry(_aconnString, "currenthp", "currenthp");
                string tableName = _atableName;
                string currenthp = _tableentry.GetCurrentHourPartition(tableName);

                //check partition. close prev. partition file, if partition is changed.
                if (currenthp != _hourlypartition && currenthp != null)
                {
                    ClosePrevPartitionFile(currenthp);
                }

                using (var stream = _adlsFileSystemClient.FileSystem.Open(_adlsAccountName, _eventMsgFile))
                {//open file in adls




                    if (!_adlsFileSystemClient.FileSystem.PathExists(_adlsAccountName, _hourpartitionpath))
                    {
                        //check hour partition directory is created, if no, create
                        _adlsFileSystemClient.FileSystem.Mkdirs(_adlsAccountName, _hourpartitionpath);

                        if (!_adlsFileSystemClient.FileSystem.PathExists(_adlsAccountName, _hourpartitionpath + "/" + _hourlypartition + ".xml"))
                        {// check if file exist, if no

                            MemoryStream m = new MemoryStream();
                            StreamWriter writer = new StreamWriter(m);
                            writer.WriteLine("<?xml version=\"1.0\"?>");
                            writer.WriteLine("<aa>");

                            writer.Flush();
                            _adlsFileSystemClient.FileSystem.Create(_adlsAccountName, _hourpartitionpath + "/" + _hourlypartition.ToString() + ".xml");

                            StreamReader reader = new StreamReader(stream);
                            string data = reader.ReadToEnd();
                            data = data.Replace("<?xml version=\"1.0\"?>", "");
                            MemoryStream mStrm = new MemoryStream(Encoding.UTF8.GetBytes(data));
                            mStrm.CopyTo(m);
                            m.Position = 0;
                            _adlsFileSystemClient.FileSystem.Append(_adlsAccountName, _hourpartitionpath + "/" + _hourlypartition.ToString() + ".xml", m);
                            _tableentry.UpdateorInsertHP(tableName, _hourlypartition);

                        }
                        else
                        {
                            StreamReader reader = new StreamReader(stream);
                            string data = reader.ReadToEnd();
                            data = data.Replace("<?xml version=\"1.0\"?>", "");
                            MemoryStream mStrm = new MemoryStream(Encoding.UTF8.GetBytes(data));
                            _adlsFileSystemClient.FileSystem.Append(_adlsAccountName, _hourpartitionpath + "/" + _hourlypartition.ToString() + ".xml", mStrm);
                            _tableentry.UpdateorInsertHP(tableName, _hourlypartition);
                        }

                    }
                    else
                    {
                        if (!_adlsFileSystemClient.FileSystem.PathExists(_adlsAccountName, _hourpartitionpath + "/" + _hourlypartition + ".xml"))
                        {// check if file exist, if no

                            MemoryStream m = new MemoryStream();
                            StreamWriter writer = new StreamWriter(m);
                            writer.WriteLine("<?xml version=\"1.0\"?>");
                            writer.WriteLine("<aa>");

                            writer.Flush();
                            _adlsFileSystemClient.FileSystem.Create(_adlsAccountName, _hourpartitionpath + "/" + _hourlypartition.ToString() + ".xml");

                            StreamReader reader = new StreamReader(stream);
                            string data = reader.ReadToEnd();
                            data = data.Replace("<?xml version=\"1.0\"?>", "");
                            MemoryStream mStrm = new MemoryStream(Encoding.UTF8.GetBytes(data));
                            mStrm.CopyTo(m);
                            m.Position = 0;
                            _adlsFileSystemClient.FileSystem.Append(_adlsAccountName, _hourpartitionpath + "/" + _hourlypartition.ToString() + ".xml", m);
                            _tableentry.UpdateorInsertHP(tableName, _hourlypartition);

                        }
                        else
                        {
                            StreamReader reader = new StreamReader(stream);
                            string data = reader.ReadToEnd();
                            data = data.Replace("<?xml version=\"1.0\"?>", "");
                            MemoryStream mStrm = new MemoryStream(Encoding.UTF8.GetBytes(data));
                            _adlsFileSystemClient.FileSystem.Append(_adlsAccountName, _hourpartitionpath + "/" + _hourlypartition.ToString() + ".xml", mStrm);
                            _tableentry.UpdateorInsertHP(tableName, _hourlypartition);
                        }
                    }


                }
            }
          
        }
        // Get file or directory info
         static void ClosePrevPartitionFile(string prevPartitionFile)
        {
            MemoryStream m = new MemoryStream();
            StreamWriter writer = new StreamWriter(m);
            
            writer.WriteLine("</aa>");

            writer.Flush();
            m.Position = 0;
            _adlsFileSystemClient.FileSystem.Append(_adlsAccountName, _hourpartitionpath+"/" + prevPartitionFile.ToString() + ".xml", m);
            
        }

    }
}
