﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using Microsoft.ServiceBus.Messaging;


namespace EventSender
{
    class Program
    {
        static string eventHubName = "sbevents";
        static string connectionString = "Endpoint=sb://seventhub.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=MOkdWpMkApsCLpIffPBw/dLI9FAGgYlCcTW7Ic9H+i4=";

        static void Main(string[] args)
        {
            Console.WriteLine("Press Ctrl-C to stop the sender process");
            Console.WriteLine("Press Enter to start now");
            Console.ReadLine();
            SendingRandomMessages();

        }
        static void SendingRandomMessages()
        {
            var eventHubClient = EventHubClient.CreateFromConnectionString(connectionString, eventHubName);
            while (true)
            {
                try
                {
                    var message = "2017-03-13-11-12";
                    Console.WriteLine("{0} > Sending message: {1}", DateTime.Now, message);
                    eventHubClient.Send(new EventData(Encoding.UTF8.GetBytes(message)));
                    var message1 = "2017-03-13-11-44";
                    Console.WriteLine("{0} > Sending message: {1}", DateTime.Now, message1);
                    eventHubClient.Send(new EventData(Encoding.UTF8.GetBytes(message1)));
                }
                catch (Exception exception)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("{0} > Exception: {1}", DateTime.Now, exception.Message);
                    Console.ResetColor();
                    Console.ReadKey();
                }

                Thread.Sleep(200);
            }
        }

    }
}
